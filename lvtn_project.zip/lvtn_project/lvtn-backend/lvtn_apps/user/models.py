import os

from django.db import models
from django.contrib.auth.models import AbstractUser

# from leaveform_apps.user.models import User


class User(AbstractUser):
    user_name = models.CharField(max_length=64)
    email = models.EmailField(max_length=255)
    first_name = models.TextField(null=True, blank=True)
    last_name = models.TextField(null=True, blank=True)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(
        auto_now_add=True,
    )
    updated_at = models.DateTimeField(
        auto_now_add=True,
    )

    def __str__(self):
        return '{}'.format(self.user_name)
