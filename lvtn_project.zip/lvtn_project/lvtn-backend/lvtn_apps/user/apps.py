from django.apps import AppConfig


class UserConfig(AppConfig):
    name = 'lvtn_apps.user'
