from django.apps import AppConfig


class LvtnAppsConfig(AppConfig):
    name = 'lvtn_apps'
