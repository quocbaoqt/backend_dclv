from django.apps import AppConfig


class MessageConfig(AppConfig):
    name = 'lvtn_apps.message'
