from django.apps import AppConfig


class CommonModelsConfig(AppConfig):
    name = 'lvtn_apps.common_models'
