from django.apps import AppConfig


class ApartmentConfig(AppConfig):
    name = 'lvtn_apps.apartment'
